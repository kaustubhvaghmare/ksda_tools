irafhome="/home/kaustubh/iraf"
